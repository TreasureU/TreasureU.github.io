# CoreAnimationTest
This is a good Demo for studying CoreAnimation and CALayer!. It includes ImplicitAnimation, BasicAnimation, KeyframeAnimation, TransitionAnimation. And also introduces the usage of CAShapeLayer and CATextLayer .
