//
//  CoreAnimationTestTests.m
//  CoreAnimationTestTests
//
//  Created by willie_wei on 14-4-9.
//  Copyright (c) 2014年 willie_wei. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface CoreAnimationTestTests : XCTestCase

@end

@implementation CoreAnimationTestTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
