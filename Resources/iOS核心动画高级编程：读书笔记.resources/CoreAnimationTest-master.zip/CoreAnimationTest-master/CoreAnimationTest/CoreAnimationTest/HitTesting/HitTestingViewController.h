//
//  HitTestingViewController.h
//  CoreAnimationTest
//
//  Created by willie_wei on 14-5-12.
//  Copyright (c) 2014年 willie_wei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HitTestingViewController : UIViewController

@end
