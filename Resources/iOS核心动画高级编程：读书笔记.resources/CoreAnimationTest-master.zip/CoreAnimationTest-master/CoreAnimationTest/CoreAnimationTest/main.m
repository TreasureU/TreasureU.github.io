//
//  main.m
//  CoreAnimationTest
//
//  Created by willie_wei on 14-4-9.
//  Copyright (c) 2014年 willie_wei. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WCCAppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([WCCAppDelegate class]));
	}
}
