//
//  ImplicitAnimationsViewController.h
//  CoreAnimationTest
//
//  Created by willie_wei on 14-4-9.
//  Copyright (c) 2014年 willie_wei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/CATransform3D.h>

@interface ImplicitAnimationsViewController : UIViewController

@end
