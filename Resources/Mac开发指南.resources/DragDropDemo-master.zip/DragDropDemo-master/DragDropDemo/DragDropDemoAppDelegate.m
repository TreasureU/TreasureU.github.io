//
//  DragDropDemoAppDelegate.m
//  DragDropDemo
//
//  Created by  on 11-10-20.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "DragDropDemoAppDelegate.h"

@implementation DragDropDemoAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
